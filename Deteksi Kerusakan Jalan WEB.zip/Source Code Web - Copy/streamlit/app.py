import streamlit as st
from pymongo import MongoClient
import pandas as pd

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client["akun"]
collection = db["users"]

# Function to fetch data from MongoDB
def fetch_data(collection_name):
    collection = db[collection_name]
    cursor = collection.find({})
    data = pd.DataFrame(list(cursor))
    return data

# Set page title
st.title('MongoDB Data Visualization')

# Dropdown to select collection
collection_name = st.selectbox('Select Collection', db.list_collection_names())

# Fetch data based on selected collection
data = fetch_data(collection_name)

# Display data as table
st.subheader('Data from MongoDB')
st.write(data)

# Additional features
st.sidebar.header('Additional Features')

# Filter data
st.sidebar.subheader('Filter Data')
selected_column = st.sidebar.selectbox('Select Column', data.columns)
filter_value = st.sidebar.text_input('Enter Value to Filter')
filtered_data = data[data[selected_column].astype(str).str.contains(filter_value)]
if st.sidebar.button('Apply Filter'):
    st.write(filtered_data)

# Bar chart
st.sidebar.subheader('Bar Charts')
for column in data.select_dtypes(include=['object']):
    if st.sidebar.button(f'Show Bar Chart for {column}'):
        st.subheader(f'Bar Chart for {column}')
        st.bar_chart(filtered_data[column].value_counts())

# Download data
st.sidebar.subheader('Download Data')
if st.sidebar.button('Download Filtered Data CSV'):
    csv = filtered_data.to_csv(index=False)
    st.download_button(label="Download Filtered Data CSV", data=csv, file_name='filtered_data.csv', mime='text/csv')
